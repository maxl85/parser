<?php

// Product Export Config
$_['csvprcie_pro_config_product_export'] = array(
	'truncate_price' => true,
	'decimal_places' => 4
);
