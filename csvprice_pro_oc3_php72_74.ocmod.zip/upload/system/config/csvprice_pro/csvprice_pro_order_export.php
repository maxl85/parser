<?php
$_['csvprcie_pro_config_order_export'] = array(
	'AttributeFieldDelimiter' => ',',
	'AttributeIds' => '35'
);
