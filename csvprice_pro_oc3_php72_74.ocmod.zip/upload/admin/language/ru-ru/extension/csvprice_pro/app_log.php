<?php

$_['heading_title'] = 'Журнал';
$_['heading_title_normal'] = 'CSV Price Pro import/export OC3';
$_['text_module'] = 'Модули';
$_['text_extension'] = 'Расширения';

// Text
$_['text_success'] = 'Журнал очищен!';
$_['text_list'] = 'Журнал';

// Error
$_['error_warning'] = 'Внимание: Ваш  файл ошибок %s имеет размер %s!';
$_['error_permission'] = 'У Вас нет прав для управления данным модулем!';
