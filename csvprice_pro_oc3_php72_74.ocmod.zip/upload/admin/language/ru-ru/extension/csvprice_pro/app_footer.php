<?php

// Text
$_['text_copy'] = '<p>Официальный сайт <a target="_blank" href="http://ocmod.costaslabs.com/ru/csv-price-pro-import-export">ocmod.costaslabs.com</a> '
		. '<br>Техническая поддержка <a href="mailto:support@costaslabs.com">support@costaslabs.com</a></p>'
		. '<p><a href="http://ocmod.costaslabs.com/ru/" target="_blank">ocmod.costaslabs.com</a> &copy; ' . date('Y') . ' Все права защищены.</p>';
