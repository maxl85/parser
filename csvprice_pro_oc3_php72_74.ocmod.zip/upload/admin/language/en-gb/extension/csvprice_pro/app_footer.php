<?php

// Text
$_['text_copy'] = '<p>Website: <a target="_blank" href="http://ocmod.costaslabs.com/en/csv-price-pro-import-export">ocmod.costaslabs.com</a> '
    . '<br>Technical support: <a href="mailto:support@costaslabs.com">support@costaslabs.com</a></p>'
    . '<p><a href="http://ocmod.costaslabs.com/en/" target="_blank">ocmod.costaslabs.com</a> &copy; ' . date('Y') . ' All rights reserved.</p>';