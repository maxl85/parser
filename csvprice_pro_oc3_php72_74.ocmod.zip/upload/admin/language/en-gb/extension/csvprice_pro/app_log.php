<?php
// Heading
$_['heading_title']    = 'Error Log';
$_['heading_title_normal'] = 'CSV Price Pro import/export OC3';

// Text
$_['text_module'] = 'Modules';
$_['text_extension'] = 'Extensions';
$_['text_success']     = 'Success: You have successfully cleared your error log!';
$_['text_list']        = 'Errors List';

// Error
$_['error_warning']    = 'Warning: Your error log file %s is %s!';
$_['error_permission'] = 'Warning: You do not have permission to clear error log!';