<?php
// Error
$_['error_permission'] = 'Warning: You do not have permission to modify CSV Price Pro import/export!';
$_['error_directory_not_available'] = 'The working directory <b>%s</b> is not writable or does not exist!';
$_['error_move_uploaded_file'] = 'File copying error!';
$_['error_uploaded_file'] = 'File is not uploaded!';
$_['error_copy_uploaded_file'] = 'Failed to copy file!';
$_['error_export_empty_rows'] = 'No data for export!';
$_['error_import_field_caption'] = 'Incorrect CSV header';
$_['error_unknown_error'] = 'Unknown error...';
