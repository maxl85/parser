<?php

// Text
$_['text_copy'] = '<p>Офіційний сайт <a target="_blank" href="http://ocmod.costaslabs.com/ru/csv-price-pro-import-export">ocmod.costaslabs.com</a> '
		. '<br>Технічна підтримка <a href="mailto:support@costaslabs.com">support@costaslabs.com</a></p>'
		. '<p><a href="http://ocmod.costaslabs.com/ru/" target="_blank">ocmod.costaslabs.com</a> &copy; ' . date('Y') . ' Всі права захищені.</p>';
