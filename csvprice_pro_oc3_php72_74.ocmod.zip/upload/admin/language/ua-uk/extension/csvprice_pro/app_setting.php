<?php
$_['error_permission'] = 'У Вас немає прав для зміни CSV Price Pro import/export!';
$_['error_directory_not_available'] = 'Робоча директорія модуля <b>%s</b> недоступна для запису або не існує';
$_['error_move_uploaded_file'] = 'Помилка копіювання файлу!';
$_['error_uploaded_file'] = 'Файл не завантажений!';
$_['error_copy_uploaded_file'] = 'Не вдалося скопіювати фaйл!';
$_['error_export_empty_rows'] = 'Немає даних для експорту!';
$_['error_import_field_caption'] = 'Помилка в заголовках полів CSV файлу!';
$_['error_unknown_error'] = 'Невідома помилка...';







